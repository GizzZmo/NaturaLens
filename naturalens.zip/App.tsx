
import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ControlsPanel from './components/ControlsPanel';
import DisplayArea from './components/DisplayArea';
import InteractionPanel from './components/InteractionPanel';
import ApiKeyChecker from './components/ApiKeyChecker';
import { useNaturaLensState } from './hooks/useNaturaLensState';
import { APP_NAME, TAGLINE } from './constants';

const App: React.FC = () => {
  const {
    state,
    setMode,
    setCurrentPrompt,
    setSelectedFilter,
    submitQuery,
    addHashtag,
    removeHashtag,
    toggleLike,
  } = useNaturaLensState();

  return (
    <ApiKeyChecker apiKey={process.env.API_KEY}>
      <div className="flex flex-col min-h-screen font-sans text-gray-800">
        <Header appName={APP_NAME} tagline={TAGLINE} />
        <main className="flex-grow container mx-auto p-4 flex flex-col items-center w-full max-w-4xl">
          <ControlsPanel
            mode={state.mode}
            currentPrompt={state.currentPrompt}
            selectedFilter={state.selectedFilter}
            isLoading={state.isLoading}
            onModeChange={setMode}
            onPromptChange={setCurrentPrompt}
            onFilterChange={setSelectedFilter}
            onSubmit={submitQuery}
          />
          <DisplayArea
            isLoading={state.isLoading}
            error={state.error}
            identifiedObject={state.identifiedObject}
            augmentedScene={state.augmentedScene}
            currentPrompt={state.currentPrompt}
            mode={state.mode}
          />
          {(state.identifiedObject || state.augmentedScene) && !state.isLoading && !state.error && (
            <InteractionPanel
              annotations={state.annotations}
              onAddHashtag={addHashtag}
              onRemoveHashtag={removeHashtag}
              onToggleLike={toggleLike}
            />
          )}
        </main>
        <Footer appName={APP_NAME} />
      </div>
    </ApiKeyChecker>
  );
};

export default App;
