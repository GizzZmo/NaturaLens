
import React from 'react';
import { IdentifiedObject, AugmentedScene, AppMode, GroundingChunk } from '../types';
import LoadingSpinner from './LoadingSpinner';
import SourceLinks from './SourceLinks';

interface DisplayAreaProps {
  isLoading: boolean;
  error: string | null;
  identifiedObject: IdentifiedObject | null;
  augmentedScene: AugmentedScene | null;
  currentPrompt: string;
  mode: AppMode;
}

const DisplayArea: React.FC<DisplayAreaProps> = ({
  isLoading,
  error,
  identifiedObject,
  augmentedScene,
  currentPrompt,
  mode
}) => {
  if (isLoading) {
    return (
      <div className="w-full bg-white p-6 rounded-lg shadow-xl min-h-[300px] flex flex-col justify-center items-center">
        <LoadingSpinner />
        <p className="mt-4 text-gray-600">NaturaLens is thinking...</p>
        <p className="mt-2 text-sm text-gray-500 italic">"{currentPrompt}"</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full bg-red-50 border border-red-200 p-6 rounded-lg shadow-lg min-h-[300px] flex flex-col justify-center items-center text-center">
        <div className="text-5xl mb-4">😟</div>
        <h3 className="text-xl font-semibold text-red-700 mb-2">An Error Occurred</h3>
        <p className="text-red-600">{error}</p>
        <p className="mt-4 text-sm text-gray-500">Please try refining your prompt or check your connection.</p>
      </div>
    );
  }

  if (mode === AppMode.IDENTIFY && identifiedObject) {
    return (
      <div className="w-full bg-white p-6 rounded-lg shadow-xl min-h-[300px]">
        <h2 className="text-2xl font-bold text-emerald-700 mb-3">{identifiedObject.name || "Identification Result"}</h2>
        <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{identifiedObject.description}</p>
        {identifiedObject.sourceLinks && identifiedObject.sourceLinks.length > 0 && (
          <SourceLinks sources={identifiedObject.sourceLinks} />
        )}
      </div>
    );
  }

  if (mode === AppMode.AUGMENT && augmentedScene) {
    return (
      <div className="w-full bg-white p-6 rounded-lg shadow-xl min-h-[300px] flex flex-col items-center">
        <h3 className="text-xl font-semibold text-emerald-700 mb-3">
          Scene: <span className="italic">"{augmentedScene.prompt}"</span> - Filter: <span className="font-bold">{augmentedScene.filterName}</span>
        </h3>
        <img
          src={augmentedScene.imageUrl}
          alt={`Augmented scene: ${augmentedScene.prompt} with ${augmentedScene.filterName} filter`}
          className="rounded-md shadow-lg max-w-full max-h-[500px] object-contain"
        />
      </div>
    );
  }

  return (
    <div className="w-full bg-white p-6 rounded-lg shadow-xl min-h-[300px] flex flex-col justify-center items-center text-center">
      <div className="text-6xl mb-4">🌿</div>
      <h3 className="text-xl font-semibold text-gray-700 mb-2">Welcome to NaturaLens</h3>
      <p className="text-gray-600">Describe a natural scene or object in the panel above.</p>
      <p className="text-gray-500">Choose 'Identify Nature' for information or 'Augment Scene' to apply artistic filters.</p>
    </div>
  );
};

export default DisplayArea;
