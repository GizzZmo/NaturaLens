
import React from 'react';

interface ApiKeyCheckerProps {
  apiKey?: string;
  children: React.ReactNode;
}

const ApiKeyChecker: React.FC<ApiKeyCheckerProps> = ({ apiKey, children }) => {
  if (!apiKey) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-red-50 p-4">
        <div className="text-5xl mb-4">🔑</div>
        <h1 className="text-2xl font-bold text-red-700 mb-2">API Key Missing</h1>
        <p className="text-red-600 text-center max-w-md">
          The NaturaLens application requires a Google Gemini API key to function.
          Please ensure the <code className="bg-red-100 p-1 rounded">API_KEY</code> environment variable is set.
        </p>
        <p className="mt-4 text-sm text-gray-500">
          This is a simulated environment. In a real deployment, this key would be configured on the server or build environment.
        </p>
      </div>
    );
  }

  return <>{children}</>;
};

export default ApiKeyChecker;
