
import React from 'react';
import { AppMode } from '../types';
import { ARTISTIC_FILTERS } from '../constants';
import FilterSelector from './FilterSelector';

interface ControlsPanelProps {
  mode: AppMode;
  currentPrompt: string;
  selectedFilter: string;
  isLoading: boolean;
  onModeChange: (mode: AppMode) => void;
  onPromptChange: (prompt: string) => void;
  onFilterChange: (filterId: string) => void;
  onSubmit: () => void;
}

const ControlsPanel: React.FC<ControlsPanelProps> = ({
  mode,
  currentPrompt,
  selectedFilter,
  isLoading,
  onModeChange,
  onPromptChange,
  onFilterChange,
  onSubmit,
}) => {
  const handlePromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-xl w-full mb-8">
      <div className="flex justify-center mb-6 space-x-2">
        {(Object.keys(AppMode) as Array<keyof typeof AppMode>).map((key) => (
          <button
            key={AppMode[key]}
            onClick={() => onModeChange(AppMode[key])}
            disabled={isLoading}
            className={`px-6 py-3 rounded-md font-semibold text-sm transition-all duration-150 ease-in-out
                        ${mode === AppMode[key] ? 'bg-emerald-500 text-white shadow-md' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}
                        disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {AppMode[key] === AppMode.IDENTIFY ? '🏞️ Identify Nature' : '🎨 Augment Scene'}
          </button>
        ))}
      </div>

      <form onSubmit={handlePromptSubmit}>
        <textarea
          value={currentPrompt}
          onChange={(e) => onPromptChange(e.target.value)}
          placeholder={
            mode === AppMode.IDENTIFY
              ? "Describe a natural object or scene to identify (e.g., 'a tall pine tree with long needles', 'a red bird with a black mask')"
              : "Describe a scene to augment with a filter (e.g., 'a misty mountain range at dawn', 'a vibrant coral reef teeming with fish')"
          }
          rows={3}
          className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-shadow resize-none mb-4"
          disabled={isLoading}
        />

        {mode === AppMode.AUGMENT && (
          <FilterSelector
            filters={ARTISTIC_FILTERS}
            selectedFilter={selectedFilter}
            onFilterChange={onFilterChange}
            disabled={isLoading}
          />
        )}

        <button
          type="submit"
          disabled={isLoading || !currentPrompt.trim()}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-md transition-all duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </>
          ) : (
            mode === AppMode.IDENTIFY ? 'Identify Nature' : 'Augment Scene'
          )}
        </button>
      </form>
    </div>
  );
};

export default ControlsPanel;
