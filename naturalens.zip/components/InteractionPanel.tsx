
import React, { useState } from 'react';
import { Annotation } from '../types';

interface InteractionPanelProps {
  annotations: Annotation;
  onAddHashtag: (tag: string) => void;
  onRemoveHashtag: (tag: string) => void;
  onToggleLike: () => void;
}

const InteractionPanel: React.FC<InteractionPanelProps> = ({
  annotations,
  onAddHashtag,
  onRemoveHashtag,
  onToggleLike,
}) => {
  const [currentHashtag, setCurrentHashtag] = useState('');

  const handleAddHashtag = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentHashtag.trim()) {
      onAddHashtag(currentHashtag.trim().toLowerCase().replace(/\s+/g, '-'));
      setCurrentHashtag('');
    }
  };

  return (
    <div className="w-full bg-white p-6 rounded-lg shadow-xl mt-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        {/* Likes Section */}
        <div className="flex items-center mb-4 md:mb-0">
          <button
            onClick={onToggleLike}
            className={`p-2 rounded-full transition-colors duration-150 ease-in-out mr-2
                        ${annotations.likes > 0 ? 'text-red-500 hover:bg-red-100' : 'text-gray-500 hover:bg-gray-100'}`}
            aria-label={annotations.likes > 0 ? "Unlike" : "Like"}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
            </svg>
          </button>
          <span className="text-gray-700 font-semibold">{annotations.likes} like{annotations.likes !== 1 ? 's' : ''}</span>
        </div>

        {/* Hashtags Section */}
        <div className="flex-grow md:ml-6">
          <form onSubmit={handleAddHashtag} className="flex items-center mb-2">
            <input
              type="text"
              value={currentHashtag}
              onChange={(e) => setCurrentHashtag(e.target.value)}
              placeholder="Add a hashtag (e.g., #sunset)"
              className="flex-grow p-2 border border-gray-300 rounded-l-md focus:ring-1 focus:ring-emerald-500 focus:border-transparent text-sm"
            />
            <button
              type="submit"
              className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-r-md font-semibold text-sm transition-colors"
            >
              Add Tag
            </button>
          </form>
          {annotations.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {annotations.hashtags.map((tag) => (
                <span key={tag} className="bg-teal-100 text-teal-700 px-3 py-1 rounded-full text-xs font-medium flex items-center">
                  #{tag}
                  <button
                    onClick={() => onRemoveHashtag(tag)}
                    className="ml-2 text-teal-500 hover:text-teal-700"
                    aria-label={`Remove hashtag ${tag}`}
                  >
                    &times;
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
       <button
          onClick={() => alert("Share functionality is simulated. Content & annotations would be shared here!")}
          className="mt-6 w-full md:w-auto bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md transition-colors duration-150 ease-in-out flex items-center justify-center space-x-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" />
          </svg>
          <span>Share Experience</span>
        </button>
    </div>
  );
};

export default InteractionPanel;
