
import React from 'react';

interface Filter {
  id: string;
  name: string;
}

interface FilterSelectorProps {
  filters: Filter[];
  selectedFilter: string;
  onFilterChange: (filterId: string) => void;
  disabled?: boolean;
}

const FilterSelector: React.FC<FilterSelectorProps> = ({ filters, selectedFilter, onFilterChange, disabled }) => {
  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold text-gray-700 mb-3">Select an Artistic Filter:</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {filters.map((filter) => (
          <button
            key={filter.id}
            onClick={() => onFilterChange(filter.id)}
            disabled={disabled}
            className={`p-3 border rounded-lg text-sm font-medium transition-all duration-150 ease-in-out
                        ${selectedFilter === filter.id
                          ? 'bg-emerald-500 text-white border-emerald-600 shadow-md ring-2 ring-emerald-300'
                          : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100 hover:border-gray-400'}
                        disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white`}
          >
            {filter.name}
          </button>
        ))}
      </div>
    </div>
  );
};

export default FilterSelector;
