
import React from 'react';
import { GroundingChunk } from '../types';

interface SourceLinksProps {
  sources: GroundingChunk[];
}

const SourceLinks: React.FC<SourceLinksProps> = ({ sources }) => {
  const webSources = sources.filter(s => s.web && s.web.uri && s.web.title);

  if (webSources.length === 0) {
    return null;
  }

  return (
    <div className="mt-6 pt-4 border-t border-gray-200">
      <h4 className="text-md font-semibold text-gray-600 mb-2">Sources:</h4>
      <ul className="list-disc list-inside space-y-1">
        {webSources.map((source, index) => (
          source.web && ( // type guard
            <li key={index} className="text-sm">
              <a
                href={source.web.uri}
                target="_blank"
                rel="noopener noreferrer"
                className="text-emerald-600 hover:text-emerald-800 hover:underline transition-colors"
                title={source.web.uri}
              >
                {source.web.title || source.web.uri}
              </a>
            </li>
          )
        ))}
      </ul>
    </div>
  );
};

export default SourceLinks;
