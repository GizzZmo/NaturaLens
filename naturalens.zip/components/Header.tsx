
import React from 'react';

interface HeaderProps {
  appName: string;
  tagline: string;
}

const Header: React.FC<HeaderProps> = ({ appName, tagline }) => {
  return (
    <header className="bg-gradient-to-r from-teal-500 via-green-500 to-emerald-600 text-white p-6 shadow-md w-full">
      <div className="container mx-auto text-center">
        <h1 className="text-4xl font-bold tracking-tight">{appName} 🌿</h1>
        <p className="text-lg opacity-90 mt-1">{tagline}</p>
      </div>
    </header>
  );
};

export default Header;
