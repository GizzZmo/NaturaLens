
import React from 'react';

interface FooterProps {
  appName: string;
}

const Footer: React.FC<FooterProps> = ({ appName }) => {
  return (
    <footer className="bg-gray-800 text-white p-4 text-center w-full mt-8">
      <p>&copy; {new Date().getFullYear()} {appName}. All rights reserved. (Simulated Experience)</p>
    </footer>
  );
};

export default Footer;
