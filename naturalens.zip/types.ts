
export enum AppMode {
  IDENTIFY = 'IDENTIFY',
  AUGMENT = 'AUGMENT',
}

export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web?: GroundingChunkWeb;
  retrievalQuery?: string;
  retrievalBasis?: string;
  // Other types of chunks can be added here if needed
}

export interface IdentifiedObject {
  name: string;
  description: string;
  sourceLinks?: GroundingChunk[];
}

export interface AugmentedScene {
  prompt: string;
  filterName: string;
  imageUrl: string;
}

export interface Annotation {
  hashtags: string[];
  likes: number;
}

export interface NaturaLensState {
  mode: AppMode;
  currentPrompt: string;
  identifiedObject: IdentifiedObject | null;
  augmentedScene: AugmentedScene | null;
  annotations: Annotation;
  isLoading: boolean;
  error: string | null;
  selectedFilter: string; // filter ID
}
