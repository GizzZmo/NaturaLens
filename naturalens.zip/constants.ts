
import { AppMode } from './types';

export const APP_NAME = "NaturaLens";
export const TAGLINE = "A 'Social Lens' on the Natural World";

export const DEFAULT_APP_MODE = AppMode.IDENTIFY;

export const ARTISTIC_FILTERS = [
  { id: 'none', name: 'Natural', promptSuffix: '' },
  { id: 'vintage', name: 'Vintage', promptSuffix: ', vintage photo style, sepia tones, film grain' },
  { id: 'watercolor', name: 'Watercolor', promptSuffix: ', watercolor painting style, soft edges, vibrant colors' },
  { id: 'sketch', name: 'Sketch', promptSuffix: ', detailed pencil sketch style, monochrome, cross-hatching' },
  { id: 'pixelated', name: 'Pixel Art', promptSuffix: ', pixel art style, 8-bit, limited color palette' },
  { id: 'bioluminescent', name: 'Bioluminescent', promptSuffix: ', bioluminescent glow effect, ethereal, magical lighting, dark background' },
  { id: 'cinematic', name: 'Cinematic', promptSuffix: ', cinematic lighting, dramatic mood, wide aspect ratio look' },
  { id: 'impressionist', name: 'Impressionist', promptSuffix: ', impressionist painting style, visible brush strokes, light play' },
];

export const GEMINI_TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';
export const GEMINI_IMAGE_MODEL = 'imagen-3.0-generate-002';

export const INITIAL_ANNOTATION = { hashtags: [], likes: 0 };

export const DEFAULT_FILTER_ID = ARTISTIC_FILTERS[0].id;
