
import { useState, useCallback } from 'react';
import { NaturaLensState, AppMode, IdentifiedObject, AugmentedScene, Annotation } from '../types';
import { DEFAULT_APP_MODE, INITIAL_ANNOTATION, DEFAULT_FILTER_ID } from '../constants';
import { identifyNaturalObject, augmentSceneWithFilter } from '../services/geminiService';

export const useNaturaLensState = () => {
  const [state, setState] = useState<NaturaLensState>({
    mode: DEFAULT_APP_MODE,
    currentPrompt: '',
    identifiedObject: null,
    augmentedScene: null,
    annotations: { ...INITIAL_ANNOTATION },
    isLoading: false,
    error: null,
    selectedFilter: DEFAULT_FILTER_ID,
  });

  const setMode = useCallback((mode: AppMode) => {
    setState(prev => ({
      ...prev,
      mode,
      error: null,
      identifiedObject: null, // Clear previous results when mode changes
      augmentedScene: null,
      annotations: { ...INITIAL_ANNOTATION }, // Reset annotations
    }));
  }, []);

  const setCurrentPrompt = useCallback((prompt: string) => {
    setState(prev => ({ ...prev, currentPrompt: prompt }));
  }, []);

  const setSelectedFilter = useCallback((filterId: string) => {
    setState(prev => ({ ...prev, selectedFilter: filterId }));
  }, []);

  const submitQuery = useCallback(async () => {
    if (!state.currentPrompt.trim()) return;

    setState(prev => ({
      ...prev,
      isLoading: true,
      error: null,
      identifiedObject: null,
      augmentedScene: null,
      annotations: { ...INITIAL_ANNOTATION },
    }));

    try {
      if (state.mode === AppMode.IDENTIFY) {
        const result: IdentifiedObject = await identifyNaturalObject(state.currentPrompt);
        setState(prev => ({ ...prev, identifiedObject: result, isLoading: false }));
      } else if (state.mode === AppMode.AUGMENT) {
        const result: AugmentedScene = await augmentSceneWithFilter(state.currentPrompt, state.selectedFilter);
        setState(prev => ({ ...prev, augmentedScene: result, isLoading: false }));
      }
    } catch (err) {
      console.error("Error in submitQuery:", err);
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred.";
      setState(prev => ({ ...prev, error: errorMessage, isLoading: false }));
    }
  }, [state.currentPrompt, state.mode, state.selectedFilter]);

  const addHashtag = useCallback((tag: string) => {
    setState(prev => {
      if (prev.annotations.hashtags.includes(tag) || prev.annotations.hashtags.length >= 5) return prev; // Limit hashtags
      return {
        ...prev,
        annotations: {
          ...prev.annotations,
          hashtags: [...prev.annotations.hashtags, tag],
        },
      };
    });
  }, []);

  const removeHashtag = useCallback((tagToRemove: string) => {
    setState(prev => ({
      ...prev,
      annotations: {
        ...prev.annotations,
        hashtags: prev.annotations.hashtags.filter(tag => tag !== tagToRemove),
      },
    }));
  }, []);

  const toggleLike = useCallback(() => {
    setState(prev => ({
      ...prev,
      annotations: {
        ...prev.annotations,
        // Simple toggle for simulation: if liked, unlike (0), else like (1)
        likes: prev.annotations.likes > 0 ? 0 : (prev.annotations.likes || 0) + 1,
      },
    }));
  }, []);

  return {
    state,
    setMode,
    setCurrentPrompt,
    setSelectedFilter,
    submitQuery,
    addHashtag,
    removeHashtag,
    toggleLike,
  };
};
